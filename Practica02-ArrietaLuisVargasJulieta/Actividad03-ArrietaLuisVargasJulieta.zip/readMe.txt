Arrieta Mancera Luis Sebastian 318174116
Julieta Vargas Gutiérrez 318341945


Consideramos que esta actividad fue más fáciles que las anteriores, suponemos que se debe a que estamos comenzando a 

--- Julieta Vargas
Se me dificultó la parte 2 de esta actividad, pero con la ayuda de mi equipo pude comprenderlas mejor. Aunque hubiera estado bien dejar el extra de la practica01 como obligatorio puesto que en esta práctica si fue obligatorio implementarlo.

--- Luis Arrieta

Me parecio fácil la implementacion de la parte 1 de esta actividad.