Arrieta Mancera Luis Sebastian 318174116
Julieta Vargas Gutiérrez 318341945


Consideramos que esta práctica fue más fácil que las anteriores, suponemos que se debe a que estamos comenzando a comprender más sobre haskell.

--- Julieta Vargas

Las funciones auxiliares estuvieron fáciles. Aunque hubiera estado bien dejar el extra de la practica01 como obligatorio puesto que en esta práctica si fue obligatorio implementarlo.

--- Luis Arrieta

Me encargué de implementar la función dpll y juntar todas las funciones. En principio funciona ya que probe la práctica con configuraciones complejas y todas arrojaban el resultado esperado.
