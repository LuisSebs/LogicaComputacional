Arrieta Mancera Luis Sebastian

Los únicos problemas que me dio la practica03 fue en la implementacion
de la funcion unifmm ya que no me quedaba muy claro como implementar 
las funciones anteriores para esta funcion. Tuve que usar algunas 
funciones axuiliares como desc, sust y swap en donde si usaba las 
funciones anteriores. Esta practica a diferencia de las anteriores
si deja un poco más a conciencia del programador la implementacion
del código.