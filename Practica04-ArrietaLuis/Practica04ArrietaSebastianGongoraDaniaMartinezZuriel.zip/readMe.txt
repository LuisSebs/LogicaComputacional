Arrieta Mancera Luis Sebastian 318174116
Gongora Ramírez Dania Paula  318128274
Martínez Hernández Zuriel Enrique 318056423


-- Sebastian
Implemente los primeros ejercicios

-- Dania
Implemente los ejercicios de Numeros Naturales

-- Zuriel
Implemente los ejercicios de Litas.
