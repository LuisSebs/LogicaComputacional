Arrieta Mancera Luis Sebastian 318174116
Gongora Ramírez Dania Paula  318128274
Martínez Hernández Zuriel Enrique 318056423


-- Sebastian
Implemento los ejercicios de 1 a 8 con Dania.

-- Dania
Implemento los ejercicios de 1 a 8 con Sebastian.

-- Zuriel
Implemento los ejercios 9 y 10.